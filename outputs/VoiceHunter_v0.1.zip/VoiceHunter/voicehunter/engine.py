"""One interface for import, source estimation and stereo rendering."""
import numpy as np
from .media import SAMPLE_RATE
from .spatial import remix, mask_from_estimates, extract_stereo


def modes():
    items = [{"id": "example", "label": "選一段聲音作示範", "kind": "example", "note": "用示範段學習聲音的頻譜，再從整段錄音提取相似聲音。"},
             {"id": "speakers", "label": "雙人對話 · 指定 A 和 B", "kind": "example",
              "requires_background": True, "note": "各選 A、B 單獨說話的一段（至少 0.35 秒）。適合兩人位置相對固定的對話。"}]
    from .separation import auto_available
    if auto_available():
        items.append({"id": "auto", "label": "自動尋找聲音 · Apple 辨識", "kind": "choice", "note": "先辨識目標出現的時段，再估計音軌。片段中若始終有同一種聲音，請改用示範段。",
                      "options": [{"value": k, "label": v} for k, v in [
                          ("speech", "說話聲"), ("piano", "鋼琴"), ("guitar", "吉他"),
                          ("music", "音樂"), ("train", "列車"), ("wind", "環境風聲"),
                          ("wind_mic", "風吹麥克風")]]})
    from .pretrained import capabilities
    items.extend(m for m in capabilities() if m.get("available", False))
    return items


def separate_clip(x, mode, target="", span=None, background=None):
    if mode == "speakers":
        from .speech import separate_speakers
        t, b, meta = separate_speakers(x, SAMPLE_RATE, target_span=span, background_span=background)
    elif mode in {"example", "auto"}:
        from .separation import separate
        t, b, meta = separate(x, SAMPLE_RATE, method=mode, target=target or "speech",
                              target_span=span, background_span=background)
    else:
        from .pretrained import capabilities, separate_pretrained
        enabled = {m["id"]:m for m in capabilities() if m.get("available", False)}
        if mode not in enabled:
            raise ValueError("目前這台電腦沒有啟用這個模型。")
        t, b = separate_pretrained(x, SAMPLE_RATE, mode, target)
        if np.shape(t) in [(len(x),), (len(x), 1)]:
            mask = mask_from_estimates(t.ravel(), b.ravel())
            t, b = extract_stereo(x, mask)
        elif np.shape(t) == x.shape:
            b = x - t
        meta = {"method": mode, "note": enabled[mode]["label"]}
    t, b = np.asarray(t, np.float32), np.asarray(b, np.float32)
    if (t.shape != x.shape or b.shape != x.shape or not np.isfinite(t).all()
            or not np.isfinite(b).all()):
        raise ValueError("分軌輸出不完整，請試用另一種模式。")
    return t, b, meta


def mix_stems(t, b, gain, pan, width, *, output_mode="stereo", azimuth_deg=0):
    if not (-12 <= gain <= 12 and -1 <= pan <= 1 and 0 <= width <= 2):
        raise ValueError("參數超出範圍。")
    if output_mode == "headphones":
        from .binaural import render_headphones
        return render_headphones(t, b, SAMPLE_RATE, azimuth_deg=azimuth_deg,
                                 width=width, target_gain_db=gain)
    if output_mode != "stereo":
        raise ValueError("未知的混音模式。")
    return remix(t, b, target_gain_db=gain, pan=pan, width=width)


def read_span(params, k1, k2):
    a,b = params.get(k1), params.get(k2)
    if a is None and b is None:
        return None
    if a is None or b is None or not (np.isfinite(float(a)) and np.isfinite(float(b)) and 0 <= float(a) < float(b)):
        raise ValueError("請輸入有效的起點和終點（秒）。")
    return float(a), float(b)
